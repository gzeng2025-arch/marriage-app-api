// Marriage Assistant App - Backend (Single File Version)
// Run on Replit or Glitch without extra setup
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const { v4: uuidv4 } = require("uuid");

const app = express();
app.use(bodyParser.json());
app.use(cors());

// In-memory database (reset every time you restart)
let users = [];
let sharedSpaces = [];

// Helper: Generate random partner code
function generatePartnerCode(length = 6) {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let code = "";
  for (let i = 0; i < length; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

// ------------------ AUTH ------------------

// Register user
app.post("/api/register", (req, res) => {
  const { email, password } = req.body;
  if (users.find(u => u.email === email)) {
    return res.status(400).json({ success: false, message: "Email already exists" });
  }
  const newUser = {
    id: uuidv4(),
    email,
    password, // (⚠️ plain text, just for demo; real app should hash)
    partnerCode: generatePartnerCode(),
    partnerId: null,
    sharedSpaceId: null
  };
  users.push(newUser);
  res.json({ success: true, user: newUser });
});

// ------------------ PARTNER BINDING ------------------

app.post("/api/bind-partner", (req, res) => {
  const { userId, partnerCode } = req.body;
  const user = users.find(u => u.id === userId);
  const partner = users.find(u => u.partnerCode === partnerCode);

  if (!user || !partner) return res.status(404).json({ success: false, message: "Invalid partner code" });
  if (partner.partnerId) return res.status(400).json({ success: false, message: "Partner already bound" });

  const sharedSpace = {
    id: uuidv4(),
    members: [user.id, partner.id],
    diaries: [],
    tasks: [],
    anniversaries: [],
    loveGames: [],
    scores: []
  };
  sharedSpaces.push(sharedSpace);

  user.partnerId = partner.id;
  user.sharedSpaceId = sharedSpace.id;
  partner.partnerId = user.id;
  partner.sharedSpaceId = sharedSpace.id;

  res.json({ success: true, sharedSpaceId: sharedSpace.id });
});

// ------------------ DIARY ------------------

function fakeEmotionAnalysis(text) {
  if (text.includes("happy") || text.includes("love")) return "happy";
  if (text.includes("tired") || text.includes("stress")) return "anxious";
  if (text.includes("angry") || text.includes("fight")) return "angry";
  return "neutral";
}

app.post("/api/add-diary", (req, res) => {
  const { userId, content } = req.body;
  const user = users.find(u => u.id === userId);
  if (!user || !user.sharedSpaceId) return res.status(404).json({ success: false, message: "User or space not found" });

  const space = sharedSpaces.find(s => s.id === user.sharedSpaceId);
  const entry = { id: uuidv4(), userId, content, emotion: fakeEmotionAnalysis(content), createdAt: new Date() };
  space.diaries.push(entry);

  res.json({ success: true, entry });
});

app.get("/api/get-diaries/:spaceId", (req, res) => {
  const space = sharedSpaces.find(s => s.id === req.params.spaceId);
  if (!space) return res.status(404).json({ success: false, message: "Space not found" });
  res.json({ success: true, diaries: space.diaries });
});

// ------------------ COMMUNICATION COACH ------------------

app.post("/api/communication-coach", (req, res) => {
  const { message } = req.body;
  const calmReply = `I understand your feelings. Let's calm down and solve this together: "${message}"`;
  const empathyReply = `If I were in your partner's shoes, I might think this way: "${message}"`;
  res.json({ success: true, calmReply, empathyReply });
});

// ------------------ TASKS & ANNIVERSARIES ------------------

app.post("/api/add-task", (req, res) => {
  const { userId, title, assignedTo } = req.body;
  const user = users.find(u => u.id === userId);
  if (!user || !user.sharedSpaceId) return res.status(404).json({ success: false, message: "User or space not found" });

  const space = sharedSpaces.find(s => s.id === user.sharedSpaceId);
  const task = { id: uuidv4(), title, isDone: false, assignedTo };
  space.tasks.push(task);
  res.json({ success: true, task });
});

app.post("/api/add-anniversary", (req, res) => {
  const { userId, title, date } = req.body;
  const user = users.find(u => u.id === userId);
  if (!user || !user.sharedSpaceId) return res.status(404).json({ success: false, message: "User or space not found" });

  const space = sharedSpaces.find(s => s.id === user.sharedSpaceId);
  const ann = { id: uuidv4(), title, date };
  space.anniversaries.push(ann);
  res.json({ success: true, anniversary: ann });
});

app.get("/api/get-tasks-anniversaries/:spaceId", (req, res) => {
  const space = sharedSpaces.find(s => s.id === req.params.spaceId);
  if (!space) return res.status(404).json({ success: false, message: "Space not found" });
  res.json({ success: true, tasks: space.tasks, anniversaries: space.anniversaries });
});

app.get("/api/surprise", (req, res) => {
  const ideas = [
    "Leave a sweet note under the pillow",
    "Make a cup of coffee for your partner",
    "Give a 10-second hug",
    "Take a short evening walk together",
    "Say 3 compliments sincerely"
  ];
  res.json({ success: true, idea: ideas[Math.floor(Math.random() * ideas.length)] });
});

// ------------------ LOVE GAMES ------------------

const challenges = [
  "Hug your partner for 10 seconds",
  "Say 3 compliments",
  "Recall one happy memory",
  "Prepare a drink for your partner",
  "Send a loving text"
];

app.post("/api/generate-challenge", (req, res) => {
  const { userId } = req.body;
  const user = users.find(u => u.id === userId);
  if (!user || !user.sharedSpaceId) return res.status(404).json({ success: false, message: "User or space not found" });

  const space = sharedSpaces.find(s => s.id === user.sharedSpaceId);
  const today = new Date().toDateString();
  const existing = space.loveGames.find(g => new Date(g.date).toDateString() === today);

  if (existing) return res.json({ success: true, challenge: existing });

  const challenge = { id: uuidv4(), title: challenges[Math.floor(Math.random() * challenges.length)], date: new Date(), isCompleted: false };
  space.loveGames.push(challenge);
  res.json({ success: true, challenge });
});

app.post("/api/complete-challenge", (req, res) => {
  const { userId, sharedSpaceId } = req.body;
  const space = sharedSpaces.find(s => s.id === sharedSpaceId);
  if (!space) return res.status(404).json({ success: false, message: "Space not found" });

  const today = new Date().toDateString();
  const challenge = space.loveGames.find(g => new Date(g.date).toDateString() === today);
  if (!challenge) return res.status(404).json({ success: false, message: "No challenge today" });
  if (challenge.isCompleted) return res.status(400).json({ success: false, message: "Already completed" });

  challenge.isCompleted = true;
  challenge.completedBy = userId;

  let score = space.scores.find(s => s.userId === userId);
  if (!score) {
    space.scores.push({ userId, points: 10 });
  } else {
    score.points += 10;
  }

  res.json({ success: true, message: "Challenge completed +10 points" });
});

app.get("/api/leaderboard/:spaceId", (req, res) => {
  const space = sharedSpaces.find(s => s.id === req.params.spaceId);
  if (!space) return res.status(404).json({ success: false, message: "Space not found" });

  const leaderboard = [...space.scores].sort((a, b) => b.points - a.points);
  res.json({ success: true, leaderboard });
});

// ------------------ SERVER ------------------
const PORT = process.env.PORT || 3000;
app.get("/", (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Marriage Assistant API</title>
      <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f9f9f9; }
        h1 { color: #e91e63; }
        ul { line-height: 1.8; }
        code { background: #eee; padding: 2px 5px; border-radius: 3px; }
        .container { max-width: 700px; margin: auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        button { padding: 10px 20px; background: #e91e63; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background: #c2185b; }
        #result { margin-top: 20px; font-style: italic; }
      </style>
    </head>
    <body>
      <div class="container">
        <h1>💞 Marriage Assistant API</h1>
        <p>Status: <strong style="color:green">Running</strong></p>
        <h2>Available Endpoints</h2>
        <ul>
          <li><code>POST /api/register</code> - Register a new user</li>
          <li><code>POST /api/bind-partner</code> - Bind two users as partners</li>
          <li><code>POST /api/add-diary</code> - Add a diary entry</li>
          <li><code>GET /api/get-diaries/:spaceId</code> - Get all diary entries</li>
          <li><code>POST /api/communication-coach</code> - Get calm & empathy replies</li>
          <li><code>POST /api/add-task</code> - Add a task</li>
          <li><code>POST /api/add-anniversary</code> - Add an anniversary</li>
          <li><code>GET /api/get-tasks-anniversaries/:spaceId</code> - List tasks & anniversaries</li>
          <li><code>GET /api/surprise</code> - Get a surprise idea</li>
          <li><code>POST /api/generate-challenge</code> - Generate daily challenge</li>
          <li><code>POST /api/complete-challenge</code> - Complete today's challenge</li>
          <li><code>GET /api/leaderboard/:spaceId</code> - Show leaderboard</li>
        </ul>

        <h2>🚀 Test API</h2>
        <button onclick="testApi()">Try /api/surprise</button>
        <p id="result">Click the button to test API...</p>
      </div>

      <script>
        async function testApi() {
          try {
            const response = await fetch("/api/surprise");
            const data = await response.json();
            document.getElementById("result").innerText = "✨ Surprise idea: " + data.idea;
          } catch (err) {
            document.getElementById("result").innerText = "❌ Failed to call API.";
          }
        }
      </script>
    </body>
    </html>
  `);
});

app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
