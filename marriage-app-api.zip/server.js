const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(bodyParser.json());

// 根路由：API Docs
app.get("/", (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Marriage Assistant API</title>
      <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f9f9f9; }
        h1 { color: #e91e63; }
        ul { line-height: 1.8; }
        code { background: #eee; padding: 2px 5px; border-radius: 3px; }
        .container { max-width: 700px; margin: auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        button { padding: 10px 20px; background: #e91e63; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background: #c2185b; }
        #result { margin-top: 20px; font-style: italic; }
      </style>
    </head>
    <body>
      <div class="container">
        <h1>💞 Marriage Assistant API</h1>
        <p>Status: <strong style="color:green">Running</strong></p>
        <h2>Available Endpoints</h2>
        <ul>
          <li><code>GET /api/surprise</code> - Get a surprise idea</li>
        </ul>
        <h2>🚀 Test API</h2>
        <button onclick="testApi()">Try /api/surprise</button>
        <p id="result">Click the button to test API...</p>
      </div>
      <script>
        async function testApi() {
          try {
            const response = await fetch("/api/surprise");
            const data = await response.json();
            document.getElementById("result").innerText = "✨ Surprise idea: " + data.idea;
          } catch (err) {
            document.getElementById("result").innerText = "❌ Failed to call API.";
          }
        }
      </script>
    </body>
    </html>
  `);
});

// 測試 API
app.get("/api/surprise", (req, res) => {
  const ideas = [
    "Write a love note",
    "Cook dinner together",
    "Take a walk in the park",
    "Plan a weekend trip",
    "Give a 10-second hug"
  ];
  const idea = ideas[Math.floor(Math.random() * ideas.length)];
  res.json({ idea });
});

// 啟動伺服器
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`🚀 Server running on port ${port}`));
